import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:async';


class PeticionesServicios {
  Future<bool> setServicios(contenido) async {
    try {
      var uri = Uri.parse("https://serviciostaller.onrender.com/api/servicios");
      final response = await http.post(uri,
          headers: {
            'Content-Type': 'application/json',
          },
          body: jsonEncode(contenido));

      if (response.statusCode == 201) {
        return true;
      }
    } catch (e) {
      return false;
    }

    return false;
  }

  Future<dynamic> getServicios() async {
    try {
      var uri = Uri.parse("https://serviciostaller.onrender.com/api/servicios");
      final response = await http.get(uri);

      if (response.statusCode == 200) {

        return jsonDecode(response.body);
      }
    } catch (e) {
      return jsonEncode({"error": "conexion fallida."});
    }
  }

}
