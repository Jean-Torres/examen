import 'package:examen/widgets/formulario.dart';
import 'package:examen/widgets/listar_servicios.dart';
import 'package:examen/widgets/menu_lateral.dart';
import 'package:flutter/material.dart';

class Principal extends StatefulWidget {
  const Principal({super.key});

  @override
  State<Principal> createState() => _PrincipalState();
}

class _PrincipalState extends State<Principal> {
  String selectedOption = "inicio";
  void selectDrawerOption(String option) {
    setState(() {
      selectedOption = option;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        drawer: MenuLateral(onChanged: selectDrawerOption),
        appBar: AppBar(title: const Text("Taller mecanico")),
        body: buildBody(),
      ),
    );
  }

  Widget buildBody() {
    switch (selectedOption) {
      case "inicio":
        return ListaServicios(funcion: selectDrawerOption);
      case "nuevo servicio":
        return NuevoServicio(
          callback: selectDrawerOption,
        );
    }
    return ListaServicios(funcion: selectDrawerOption);
  }
}
